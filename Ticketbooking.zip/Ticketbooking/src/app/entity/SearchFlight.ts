export default class SearchFlight{
    date: Date = new Date;
    fromLocation: string = "";
    toLocation: string = "";
    oneWay: string = ''; 
    roundTrip: string = ''; 
    travellers:number=0;
}