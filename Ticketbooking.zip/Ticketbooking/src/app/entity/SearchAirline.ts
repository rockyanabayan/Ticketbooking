export default class SearchAirline{
    
    airline:string='';
    filghtnumber:String="";
   
    instrumentused:string='';
   }