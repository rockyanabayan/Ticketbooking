export default class AirlineList{
 
    logo:string='';
    filghtname:string='';
    contactnumber:number=0;
    briefwriteup:string='';    
}