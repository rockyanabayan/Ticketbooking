export default class BookingHistory{
   
    date:Date=new Date();
    returnjourney:Date=new Date();
    logo:string='';
    price:number=0;
    seats:number=0;
    
}
    