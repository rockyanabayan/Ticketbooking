export default class ManageBooking{
   
    
    airlinelogo:string='';
    price:number=0;
   
   date:Date=new Date();  
    
}