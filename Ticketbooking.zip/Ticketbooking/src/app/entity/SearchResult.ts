export default class SearchResult{
   
    
    logo:string='';
    fromlocation:string='';
   
    tolocation:string='';  
    flightnumber:string=''; 
}