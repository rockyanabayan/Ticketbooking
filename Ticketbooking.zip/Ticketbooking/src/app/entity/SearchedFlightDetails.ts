export default class SearchedFlightDetails{
   
    filghtnumber:String="";
    fromPlace:string='';
    toPlace:string='';
    instrumentused:string='';   
    totalSeats:number=0;
    meal:string='';
    scheduleDays:string='';

    logo:string='';
    startDateTime:string='';
   
    endDateTime:string='';  
    airlineName:string=''; 
    price:number=0; 
}